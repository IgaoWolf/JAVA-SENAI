package com.senai.tela;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;

public class Tela extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField textNome;
	private JLabel labelNome;
	private JPanel panelCentral;
	private JPanel panelInferior;
	private JLabel labelRodape;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JPanel panelSuperior;
	private JTextField textGrid1;
	private JTextField textGrid2;
	private JTextField textGrid3;
	private JTextField textField_5;

	public Tela() {
		
		initComponents();
		
	}

	private void initComponents() {
		panelCentral = new JPanel();
		panelCentral.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Dados Pessoais", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		getContentPane().add(panelCentral, BorderLayout.CENTER);
		panelCentral.setLayout(null);
		
		labelNome = new JLabel("Nome");
		labelNome.setBounds(87, 24, 27, 14);
		panelCentral.add(labelNome);
		
		textNome = new JTextField();
		textNome.setBounds(132, 21, 86, 20);
		panelCentral.add(textNome);
		textNome.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(228, 21, 86, 20);
		panelCentral.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(319, 21, 86, 20);
		panelCentral.add(textField_1);
		textField_1.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(106, 113, 86, 20);
		panelCentral.add(textField_5);
		textField_5.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(410, 21, 86, 20);
		panelCentral.add(textField_4);
		textField_4.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(501, 21, 86, 20);
		panelCentral.add(textField_3);
		textField_3.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(592, 21, 86, 20);
		panelCentral.add(textField_2);
		textField_2.setColumns(10);
		
		panelInferior = new JPanel();
		getContentPane().add(panelInferior, BorderLayout.SOUTH);
		
		labelRodape = new JLabel("Rodap\u00E9 da tela");
		panelInferior.add(labelRodape);
		
		panelSuperior = new JPanel();
		panelSuperior.setBorder(new TitledBorder(null, "Tabela Coisada", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		getContentPane().add(panelSuperior, BorderLayout.NORTH);
		panelSuperior.setLayout(new GridLayout(2, 3, 0, 0));
		
		textGrid1 = new JTextField();
		panelSuperior.add(textGrid1);
		textGrid1.setColumns(40);
		
		textGrid2 = new JTextField();
		panelSuperior.add(textGrid2);
		textGrid2.setColumns(40);
		
		textGrid3 = new JTextField();
		panelSuperior.add(textGrid3);
		textGrid3.setColumns(40);
		
//		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(800, 600);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Tela();
	}
}

